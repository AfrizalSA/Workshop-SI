<?php //if (!defined('BASEPATH')) exit('No direct script access allowed');

class Andro extends CI_Controller
{
    public function __construct()
    {
        parent::__construct();
        $this->load->model('driver_login_model');
        $this->load->helper(array('form', 'url'));
    }

    public function index()
    {
               
         echo "welcome parsing data";
    }

    public function loginapi()
    { 
        $method= $_SERVER['REQUEST_METHOD'];
        if ($method != 'POST'){
          echo  json_encode(array('status' => 400 , 'message' => 'access deny'));
        }else{
        $username = $this->input->post('username');
        $password = $this->input->post('password');
        if($username==null){
            echo  json_encode(array('status' => 302 , 'message' => 'username tidak boleh kosong'));
        }elseif($password==null){
            echo  json_encode(array('status' => 302 , 'message' => 'password tidak boleh kosong'));
        }else{
        $cek= $this->driver_login_model->loginapi($username,$password);
        $hasil= count($cek);
        if($hasil > 0){           
            //$data = $this->driver_login_model->LoginApi($username,$password);
            $a=array('status' => $hasil,'message' => 'Login Sukses');//,$data);
            echo json_encode($a);}
        else{$a=array('status' => $hasil,'message' => 'Login Gagal');
            echo json_encode($a);}
            }
            # code...
        }
        
    }
    public function gettransdata()
    { 
        $method= $_SERVER['REQUEST_METHOD'];
        if ($method != 'POST'){
          echo  json_encode(array('status' => 400 , 'message' => 'access deny'));
        }else{
        $ID_SOPIR = $this->input->post('ID_SOPIR'); 
        $data = $this->driver_login_model->gettrans($ID_SOPIR);
        $parsing=array('status' => 'sukses',
            'ID_SURAT_JALAN' => $data[0]->ID_SURAT_JALAN,
            'NAMA_PEMESAN' => $data[0]->NAMA_PEMESAN,
            'ALAMAT_PEMESAN' => $data[0]->ALAMAT_PEMESAN,
            'NOHP_PEMESAN' => $data[0]->NOHP_PEMESAN,
            'BARANG_DIPESAN' => $data[0]->NAMA_BARANG,
            'KOORDINAT_PEMESAN' => $data[0]->KOORDINAT_PEMESAN
            );
                   
            echo json_encode($parsing);}
        
            //$a=array('status' => $hasil,'message' => 'Login Sukses',$data);
            
        
            # code...
        }
    public function getdata()
    { 
        $method= $_SERVER['REQUEST_METHOD'];
        if ($method != 'POST'){
          echo  json_encode(array('status' => 400 , 'message' => 'access deny'));
        }else{
        $username = $this->input->post('username');
        $password = $this->input->post('password');   
        $data = $this->driver_login_model->loginapi($username,$password);
        $parsing=array('ID_SOPIR' => $data[0]->ID_SOPIR,
        'NAMA_SOPIR' => $data[0]->NAMA_SOPIR,
        'ALAMAT_SOPIR' => $data[0]->ALAMAT_SOPIR,
        'NOHP_SOPIR' => $data[0]->NOHP_SOPIR,
        'PLAT_NOMOR' => $data[0]->PLAT_NOMOR,
        //'EMAIL' => $data[0]->EMAIL,
        //'PASSWORD' => $data[0]->PASSWORD,
        'JENIS_KENDARAAN' => $data[0]->NAMA_JENIS
);
            //$a=array('status' => $hasil,'message' => 'Login Sukses',$data);
            echo json_encode($parsing);}
        
            # code...
        }
    public function updateselesai(){
       $method= $_SERVER['REQUEST_METHOD'];
        if ($method != 'POST'){
          echo  json_encode(array('status' => 400 , 'message' => 'access deny'));
        }else{
        $config['upload_path']          = './assets/';
        $config['allowed_types']        = 'gif|jpg|png';
        $config['max_size']             = 10000;
        //$config['max_width']            = 1024;
        //$config['max_height']           = 768;
        $ID_SURAT = $this->input->post('ID_SURAT_JALAN');
        $ID_SOPIR = $this->input->post('ID_SOPIR');
        $this->load->library('upload', $config);
        if ( ! $this->upload->do_upload('berkas')){
            $io=$this->upload->display_errors();
            $error = array('status' => 'gagal','error' => $io);
            echo json_encode($error);
        }else{
            $a=$this->upload->data();
            $data = array('status' => 'sukses','upload_data' => $a['file_name']);
            
            $insert = $this->driver_login_model->updatesurat(array('FOTO' => $a['file_name'],'STATUS_PENGIRIMAN' => '3'), $ID_SURAT);
            echo json_encode($data); 
            $insert = $this->driver_login_model->updatesopir(array(
            'STATUS_KENDARAAN' => '1'), $ID_SOPIR);
            $b=$this->driver_login_model->getsurat($ID_SURAT);
            //var_dump($b);
                //echo $b[0]->ID_SURAT_JALAN;
            $laporan = $this->driver_login_model->laporan(array (
            'SURAT_JALAN' => $b[0]->ID_SURAT_JALAN,
            'TANGGAL_LAPORAN' => date("F j, Y,G:H:i"),
            'SOPIR' => $b[0]->ID_SOPIR,
            'TGL_SURAT_JALAN' => $b[0]->TANGGAL_SURAT_JALAN,
            'NAMA_PEMESAN' => $b[0]->NAMA_PEMESAN,
            'ALAMAT_PEMESAN' => $b[0]->ALAMAT_PEMESAN,
            'BARANG_DIPESAN' => $b[0]->BARANG_DIPESAN,
            'JUMLAH_BARANG' => $b[0]->JUMLAH_BARANG,
            'NO_PEMESAN' => $b[0]->NOHP_PEMESAN));
            }
         }
    }
    public function updatepengirim(){
       $method= $_SERVER['REQUEST_METHOD'];
       $ID_SURAT = $this->input->post('ID_SURAT_JALAN');
        if ($method != 'POST'){
          echo  json_encode(array('status' => 400 , 'message' => 'access deny'));
        }else{
            $insert = $this->driver_login_model->updatesurat(array('STATUS_PENGIRIMAN' => '2'), $ID_SURAT);
            $parsing=array('status'=>'sukses','message'=>'updated');
            echo json_encode($parsing);}
        }
     public function updategps(){
       $method= $_SERVER['REQUEST_METHOD'];
       $ID_SURAT = $this->input->post('ID_SURAT_JALAN');
       $lang = $this->input->post('lang');
       $long = $this->input->post('long');
        if ($method != 'POST'){
          echo  json_encode(array('status' => 400 , 'message' => 'access deny'));
        }else{
            $insert = $this->driver_login_model->updatesurat(array('KOORDINAT_DRIVER' => $lang.' | '.$long), $ID_SURAT);
             $parsing=array('status'=>'sukses','message'=>'updated');
            echo json_encode($parsing);
        }
    }

}