<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class suratjalan extends CI_Controller {
	 public function __Construct() {
        parent::__Construct();
        //$this->load->library('googlemaps');
        
      	$this->load->model('suratjalan_model');
       if(!$this->session->userdata('logger')) {
            redirect('login');
}
}
	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see https://codeigniter.com/user_guide/general/urls.html
	 */


	public function index(){
if(isset($_POST['changeSubmit'])){

$address=$this->input->post('ALAMAT_PEMESAN');
	
	$data_arr = $this->suratjalan_model->geocode($address);
	$latitude = $data_arr[0];
    $longitude = $data_arr[1];
    //echo $$latitude."|".$longitude;
	$data = $this->suratjalan_model->input(array (
	'NAMA_PEMESAN' => $this->input->post('NAMA_PEMESAN'),
	'ALAMAT_PEMESAN' => $this->input->post('ALAMAT_PEMESAN'),
	'NOHP_PEMESAN' => $this->input->post('NOHP_PEMESAN'),
	'BARANG_DIPESAN' => $this->input->post('BARANG_DIPESAN'),
	'JUMLAH_BARANG' => $this->input->post('JUMLAH_BARANG'),
	'TANGGAL_SURAT_JALAN' => date("F j, Y,G:H:i");,
	'ID_SOPIR' => $this->input->post('ID_SOPIR'),
	/*'NAMA_SOPIR' => $this->input->post('NAMA_SOPIR'),
	'NOHP_SOPIR' => $this->input->post('NOHP_SOPIR'),
	'PLAT_NOMOR' => $this->input->post('PLATNOMOR'),*/
	'KOORDINAT_PEMESAN' => $latitude." | ".$longitude
	//'JENIS_KENDARAAN' => $this->input->post('JENIS_KENDARAAN')
	));
	$ID_SOPIR = $this->input->post('ID_SOPIR');
	$insert = $this->suratjalan_model->update(array(
	'STATUS_KENDARAAN' => $this->input->post('STATUS_KENDARAAN')), $ID_SOPIR);
	redirect('suratjalan');
	
}else{
	$x =$this->suratjalan_model->get_barang();
	$y =$this->suratjalan_model->get_datasopir();
	$data = array(
	'ID_SOPIR'=>$this->suratjalan_model->get_datasopir(),
	'ID_BARANG'=>$this->suratjalan_model->get_barang(),
    'NAMA_SOPIR' => $this->suratjalan_model->get_data_edit(),
		);
        //var_dump($data);
     	$data['ID_JENIS']= $this->suratjalan_model->get_jenis();
     	$data['NAMA_JENIS']= $this->suratjalan_model->get_jenis();
	//var_dump($x);
	$this->load->view('surat_jalan',$data);
		# code...
}
}}


	

