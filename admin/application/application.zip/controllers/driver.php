<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class driver extends CI_Controller {

 public function __Construct() {
        parent::__Construct();
      	$this->load->model('Driver_model');
       if(!$this->session->userdata('logger')) {
            redirect('login');
        }
    }
	public function index()
	{
		if (isset($_POST['changeSubmit'])){
			$data2 = $this->Driver_model->input(array (
			'ID_SOPIR' => $this->input->post('NIK'),
			'NAMA_SOPIR' => $this->input->post('NAMA'),
			'ALAMAT_SOPIR' => $this->input->post('ALAMAT'),
			'NOHP_SOPIR' => $this->input->post('NOHP_SOPIR'),
			'PLAT_NOMOR' => $this->input->post('PLATNOMOR'),
			'EMAIL' => $this->input->post('EMAIL'),
			'PASSWORD' => $this->input->post('PASSWORD'),
			'STATUS_KENDARAAN' => $this->input->post('STATUS_KENDARAAN'),
			'JENIS_KENDARAAN' => $this->input->post('JENIS_KENDARAAN')));
			redirect('driver');
		}else{
			//$x =$this->Driver_model->get_jenis();
			
			//var_dump($x);
			//$this->load->view('',$data);

		$config['base_url'] = site_url('driver/index'); //site url
        $config['total_rows'] = $this->db->count_all('sopir'); //total row
        $config['per_page'] = 5;  //show record per halaman
        $config["uri_segment"] = 3;  // uri parameter
        $choice = $config["total_rows"] / $config["per_page"];
        $config["num_links"] = floor($choice);
 
        // Membuat Style pagination untuk BootStrap v4
      $config['first_link']       = 'First';
        $config['last_link']        = 'Last';
        $config['next_link']        = 'Next';
        $config['prev_link']        = 'Prev';
        $config['full_tag_open']    = '<div class="pagging text-center"><nav><ul class="pagination justify-content-center">';
        $config['full_tag_close']   = '</ul></nav></div>';
        $config['num_tag_open']     = '<li class="page-item"><span class="page-link">';
        $config['num_tag_close']    = '</span></li>';
        $config['cur_tag_open']     = '<li class="page-item active"><span class="page-link">';
        $config['cur_tag_close']    = '<span class="sr-only">(current)</span></span></li>';
        $config['next_tag_open']    = '<li class="page-item"><span class="page-link">';
        $config['next_tagl_close']  = '<span aria-hidden="true">&raquo;</span></span></li>';
        $config['prev_tag_open']    = '<li class="page-item"><span class="page-link">';
        $config['prev_tagl_close']  = '</span>Next</li>';
        $config['first_tag_open']   = '<li class="page-item"><span class="page-link">';
        $config['first_tagl_close'] = '</span></li>';
        $config['last_tag_open']    = '<li class="page-item"><span class="page-link">';
        $config['last_tagl_close']  = '</span></li>';
 
        $this->pagination->initialize($config);
        $data['page'] = ($this->uri->segment(3)) ? $this->uri->segment(3) : 0;
 
        //panggil function get_mahasiswa_list yang ada pada mmodel mahasiswa_model.  
 $data = array(
				'jenis'=>$this->Driver_model->get_jenis(),
				'data'=>$this->Driver_model->get_sopir($config["per_page"], $data['page']),
        		'pagination' => $this->pagination->create_links());
 
        //load view mahasiswa view
        $this->load->view('Driver',$data);
			//$data1 = array(
				
		//$this->load->view('App/list_mhs',['data' => $data]);
			//$this->load->view('Driver',$data1);
	}
}
	public function logout()
	{
		$this->session->sess_destroy();
		redirect('/login');
	}
	/*function create(){
		if (isset($_POST['changeSubmit'])){
			$data2 = $this->Driver_model->input(array (
			'ID_SOPIR' => $this->input->post('NIK'),
			'NAMA_SOPIR' => $this->input->post('NAMA'),
			'ALAMAT_SOPIR' => $this->input->post('ALAMAT'),
			'NOHP_SOPIR' => $this->input->post('NOHP_SOPIR'),
			'PLAT_NOMOR' => $this->input->post('PLATNOMOR'),
			'EMAIL' => $this->input->post('EMAIL'),
			'PASSWORD' => $this->input->post('PASSWORD'),
			'STATUS_KENDARAAN' => $this->input->post('STATUS_KENDARAAN'),
			'JENIS_KENDARAAN' => $this->input->post('JENIS_KENDARAAN')));
			redirect('driver');
		}else{
			$x =$this->Driver_model->get_jenis();
			$data1 = array(
				'jenis'=>$this->Driver_model->get_jenis()
				);
			//var_dump($x);
			$this->load->view('create',$data1);
		}
	}*/
		function delete($ID_SOPIR){
		$this->Driver_model->delete($ID_SOPIR);
		redirect('driver');
	}
	function edit(){
		$ID = $this->uri->segment(3);
		$data3 = array(
            'NAMA_SOPIR' => $this->Driver_model->get_data_edit($ID),
		);
        //var_dump($data);
     	$data3['ID_JENIS']= $this->Driver_model->get_jenis();
     	$data3['NAMA_JENIS']= $this->Driver_model->get_jenis();


        $this->load->view("update", $data3);
	
		
	}
	
	function update(){
		$ID_SOPIR = $this->input->post('ID_SOPIR');
		$insert = $this->Driver_model->update(array(   
			'NAMA_SOPIR' => $this->input->post('NAMA_SOPIR'),
			'ALAMAT_SOPIR' => $this->input->post('ALAMAT_SOPIR'),
			'NOHP_SOPIR' => $this->input->post('NOHP_SOPIR'),
			'PLAT_NOMOR' => $this->input->post('PLATNOMOR'),
			'EMAIL' => $this->input->post('EMAIL'),
			'PASSWORD' => $this->input->post('PASSWORD'),
			'STATUS_KENDARAAN' => $this->input->post('STATUS_KENDARAAN'),
			'JENIS_KENDARAAN' => $this->input->post('JENIS_KENDARAAN')
            ), $ID_SOPIR);
		//var_dump($insert);
        redirect('driver');
        }
        
}
