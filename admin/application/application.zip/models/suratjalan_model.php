<?php
class suratjalan_model extends CI_Model {

	function get_table(){
        return $this->db->get("surat_jalan");
    }
    
	function get_datasopir(){
		$query = $this->db->query("SELECT * FROM sopir WHERE STATUS_KENDARAAN = 1" );
		return $query->result();
	}
	function get_barang(){
		$query = $this->db->query("SELECT * FROM barang");
		return $query->result();
	}
			function get_jenis(){
		$query = $this->db->query("SELECT * FROM jenis_kendaraan");
		return $query->result();
	}
	
	function get_data_edit(){
		$query = $this->db->query("SELECT * FROM sopir");
		return $query->result_array();
	}
	
	function input($data = array()){
		return $this->db->insert('surat_jalan',$data);
	
	}
	function update($data = array(),$ID_SOPIR){
		$this->db->where('ID_SOPIR',$ID_SOPIR);
		return $this->db->update('sopir',$data);
	}
	function select_all_user($ID_SOPIR){        
        $query="select * from sopir where ID_SOPIR='$ID_SOPIR'";
        $q=$this->db->query($query);
        if($q->num_rows()>0){
            foreach ($q->result() as $row) {
                $data[]=$row;
            }
            return $data;
        }
    }
	function geocode($address){
 
    // url encode the address
    $addres = urlencode($address);
     
    // google map geocode api url
    $url = "https://maps.googleapis.com/maps/api/geocode/json?address=".$addres."&key=AIzaSyAaXtFjL-GmaVRwPxk2BXBDWJbsAeBgLt8";
 
    // get the json response
    $resp_json = file_get_contents($url);
     
    // decode the json
    $resp = json_decode($resp_json, true);
 
    // response status will be 'OK', if able to geocode given address 
    if($resp['status']=='OK'){
 
        // get the important data
        $lati = isset($resp['results'][0]['geometry']['location']['lat']) ? $resp['results'][0]['geometry']['location']['lat'] : "";
        $longi = isset($resp['results'][0]['geometry']['location']['lng']) ? $resp['results'][0]['geometry']['location']['lng'] : "";
        $formatted_address = isset($resp['results'][0]['formatted_address']) ? $resp['results'][0]['formatted_address'] : "";
         
        // verify if data is complete
        if($lati && $longi && $formatted_address){
         
            // put the data in the array
            $data_arr = array();            
             
            array_push(
                $data_arr, 
                    $lati, 
                    $longi, 
                    $formatted_address
                );
             
            return $data_arr;
             
        }else{
            return false;
        }
         
    }
 
    else{
        echo "<strong>ERROR: {$resp['status']}</strong>";
        return false;
    }
}
}