<?php
class Dashboard_model extends CI_Model {

	function get_table(){
        return $this->db->get("laporan");
    }
    
	function get_laporan($limit, $start){
        $query = $this->db->query("SELECT * FROM surat_jalan,laporan,barang,sopir WHERE laporan.SURAT_JALAN=surat_jalan.ID_SURAT_JALAN AND surat_jalan.BARANG_DIPESAN=barang.ID_BARANG AND surat_jalan.ID_SOPIR=sopir.ID_SOPIR", $limit, $start);
        return $query;
	}
}