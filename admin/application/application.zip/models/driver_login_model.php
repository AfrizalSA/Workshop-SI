<?php if (!defined('BASEPATH')) exit('No direct script access allowed');

class driver_login_model extends CI_Model
{
    function __construct()
    {
        parent::__construct();
    }

    function loginapi($username, $password)
    {   
        $result= $this->db->query("SELECT * FROM sopir,jenis_kendaraan WHERE EMAIL = '$username' AND PASSWORD = '$password' AND sopir.JENIS_KENDARAAN=jenis_kendaraan.ID_JENIS");
        return $result->result();
    }
     function gettrans($ID_SOPIR)
    {   
        $result= $this->db->query("SELECT * FROM surat_jalan,barang WHERE ID_SOPIR = '$ID_SOPIR' AND surat_jalan.BARANG_DIPESAN=barang.ID_BARANG");
        return $result->result();
    }
    function updatesopir($data = array(),$ID_SOPIR)
    {
        $this->db->where('ID_SOPIR',$ID_SOPIR);
        return $this->db->update('sopir',$data);
    }
    function updatesurat($data = array(),$ID_SURAT)
    {
        $this->db->where('ID_SURAT_JALAN',$ID_SURAT);
        return $this->db->update('surat_jalan',$data);
    }
    function getsurat($ID_SURAT)
    {   
        $result= $this->db->query("SELECT * FROM surat_jalan WHERE ID_SURAT_JALAN = '$ID_SURAT' ");
        return $result->result();
    }
    function laporan($laporan = array()){
        return $this->db->insert('laporan',$laporan);
    
    }
}