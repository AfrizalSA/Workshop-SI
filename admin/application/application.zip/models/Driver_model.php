<?php
class Driver_model extends CI_Model {

	function get_table(){
        return $this->db->get("sopir");
    }
    function get_sopir($limit, $start){
        $query = $this->db->query("SELECT * FROM sopir,jenis_kendaraan,status_kendaraan WHERE sopir.JENIS_KENDARAAN=jenis_kendaraan.ID_JENIS AND sopir.STATUS_KENDARAAN=status_kendaraan.ID_STATUS", $limit, $start);
        return $query;
    }
	//function get_data(){
	//	$query = $this->db->query("SELECT * FROM sopir,jenis_kendaraan,status_kendaraan WHERE sopir.JENIS_KENDARAAN=jenis_kendaraan.ID_JENIS AND sopir.STATUS_KENDARAAN=status_kendaraan.ID_STATUS");
	//	return $query->result();
	//}
		function get_jenis(){
		$query = $this->db->query("SELECT * FROM jenis_kendaraan");
		return $query->result();
	}
	
	function get_data_edit($ID_SOPIR){
		$query = $this->db->query("SELECT * FROM sopir WHERE ID_SOPIR = '$ID_SOPIR'");
		return $query->result_array();
	}
	
	function input($data2 = array()){
		return $this->db->insert('sopir',$data2);
	
	}
	
	function delete($ID_SOPIR){
		$this->db->where('ID_SOPIR', $ID_SOPIR);
        return $this->db->delete('sopir');
	}
	
	function update($data = array(),$ID_SOPIR){
		$this->db->where('ID_SOPIR',$ID_SOPIR);
		return $this->db->update('sopir',$data3);
	}
	
}