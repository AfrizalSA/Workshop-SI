<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Login_model extends CI_Model {

	public function prosesLogin($user,$password)
	{
		$user=$this->input->post('username',true);
		$password=$this->input->post('password',true);
		return $this->db->get('admin')->row();
	}
}